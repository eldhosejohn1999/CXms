﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using Windows.ApplicationModel.Background;
using Windows.Devices.Geolocation.Geofencing;
using Windows.Foundation;
using Windows.UI.Notifications;


namespace GEOFencingPOC.Background
{
    public sealed class AlertTask : IBackgroundTask
    {

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            var monitor = GeofenceMonitor.Current;
            if (monitor.Geofences.Any())
            {
                var reports = monitor.ReadReports();
                foreach (var report in reports)
                {
                    var l = LocationObject.GetLocationObject(report.Geofence.Id);

                    switch (report.NewState)
                    {
                        case GeofenceState.Entered:
                            {
                                ShowToast("Approaching area ", l.Name);
                                break;
                            }
                        case GeofenceState.Exited:
                            {
                                ShowToast("Leaving area ", l.Name);
                                break;
                            }
                    }
                }
            }
        }

        private const string TaskName = "POCAlerterTask";
        //NOTE:  WinRT component cannot return a Task<T>, but CAN return IAsyncOperation<T>/>
        public static IAsyncOperation<bool> Register()
        {
            return RegisterInternal().AsAsyncOperation();
        }

        private async static Task<bool> RegisterInternal()
        {
            if (!IsTaskRegistered())
            {
                await BackgroundExecutionManager.RequestAccessAsync();
                var builder = new BackgroundTaskBuilder { Name = TaskName, TaskEntryPoint = typeof(AlertTask).FullName };

                builder.SetTrigger(new LocationTrigger(LocationTriggerType.Geofence));
                builder.Register();
                return true;
            }
            return false;
        }

        public static void Unregister()
        {
            var entry = BackgroundTaskRegistration.AllTasks.FirstOrDefault(t => t.Value.Name == TaskName);

            if (entry.Value != null)
            {
                entry.Value.Unregister(true);
            }
        }

        public static bool IsTaskRegistered()
        {
            return BackgroundTaskRegistration.AllTasks.Any(t => t.Value.Name == TaskName);
        }


        private static void ShowToast(string firstLine, string secondLine)
        {
            var toastXmlContent = ToastNotificationManager.GetTemplateContent(ToastTemplateType.ToastText02);

            var txtNodes = toastXmlContent.GetElementsByTagName("text");
            txtNodes[0].AppendChild(toastXmlContent.CreateTextNode(firstLine));
            txtNodes[1].AppendChild(toastXmlContent.CreateTextNode(secondLine));

            var toast = new ToastNotification(toastXmlContent);
            var toastNotifier = ToastNotificationManager.CreateToastNotifier();
            toastNotifier.Show(toast);

            // Toast does not show up in Windows Simulator, so add a Debug to show stuff is at least working
            Debug.WriteLine("Toast: {0} {1}", firstLine, secondLine);
        }



    }
}
