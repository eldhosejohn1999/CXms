﻿using System.Collections.Generic;
using System.Linq;
using Windows.Devices.Geolocation;

namespace GEOFencingPOC.Background
{
    public sealed class LocationObject
    {

        public LocationObject()
        {
        }

        public LocationObject(string id, string name, double latitude, double longitude)
        {
            Id = id;
            Name = name;
            Location = new Geopoint(
                new BasicGeoposition { Latitude = latitude, Longitude = longitude });
        }

        public string Id { get; set; }

        public string Name { get; set; }

        public Geopoint Location { get; set; }

        public static IEnumerable<LocationObject> GetLocationObjects()
        {
            return new List<LocationObject>
             {
               new LocationObject("123","Thiruvananthapuram", 8.5241, 76.9366),
               new LocationObject("234","Kazhakoottam", 8.5710, 76.8663),
               new LocationObject("345","Pattom", 8.5207,76.9423),

             };
        }
        public static LocationObject GetLocationObject(string id)
        {
            return GetLocationObjects().FirstOrDefault(p => p.Id == id);
        }
    }
}


