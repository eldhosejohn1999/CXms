﻿using System;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using MappingUtilities.Geofencing;
using Windows.Devices.Geolocation.Geofencing;
using System.Diagnostics;
using Windows.UI;
using MappingUtilities;
using Windows.Devices.Geolocation;
using Windows.UI.Popups;
using GEOFencingPOC.Background;
using Esri.ArcGISRuntime.Layers;

namespace GeoFencingPOC
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // create a new layer (world street map tiled layer)
       // Uri uri;
       // ArcGISTiledMapServiceLayer fenceLayer;
        

        public MainPage()
        {
            this.InitializeComponent();
        }


        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            //uri = new Uri("http://services.arcgisonline.com/arcgis/rest/services/World_Street_Map/MapServer");
            //fenceLayer = new ArcGISTiledMapServiceLayer(uri);
            

            try {
                GeofenceMonitor.Current.Geofences.Clear();
            } catch(Exception er)
            {
                Debug.WriteLine(er.Message,er.StackTrace);
            }
            // set the initial view point
            var mapPoint = new Esri.ArcGISRuntime.Geometry.MapPoint(8.5241, 76.9366,
                Esri.ArcGISRuntime.Geometry.SpatialReferences.Wgs84);
            var initViewPoint = new Esri.ArcGISRuntime.Controls.ViewpointCenter(mapPoint, 250000);

            MyMap.InitialViewpoint = initViewPoint;


            // (give the layer an ID so it can be found later)
            //fenceLayer.ID = "BaseMap";

            // add the layer to the Map
            //MyMap. Layers.Add(fenceLayer);
        }


        private void DrawGeofences()
        {/*
            var color = Colors.Purple;
            color.A = 80;
            foreach (var pointlist in GeofenceMonitor.Current.GetFenceGeometries())
            {
                var shape = new MapPolygon
                {
                    FillColor = color,
                    Locations = pointlist.ToLocationCollection()
                };


                //write code for displaying these shapes in map
              //  fenceLayer.Shapes.Add(shape); //if its bing map
            }*/
        }

        private void RemoveGeofences()
        { 
            
            //write code for clearing shapes from map

            // fenceLayer.Shapes.Clear();//if its bing map
        }


        private async void ToggleTask(object sender, RoutedEventArgs e)
        {
            var registered = AlertTask.IsTaskRegistered();
            if (registered)
            {
                AlertTask.Unregister();
            }
            else
            {
                try {
                    await AlertTask.Register();
                }
                catch (Exception er) {
                    Debug.WriteLine(er.StackTrace);
                    var dlg1 = new MessageDialog(
              string.Format(""+ er.StackTrace));
                    await dlg1.ShowAsync();
                }
                 }

            var dlg = new MessageDialog(
               string.Format("Task {0}", !registered ? "registered" : "unregistered"));
            await dlg.ShowAsync();
        }


        /// <summary>
        /// Button function creating and showing (or hiding) Geofences
        /// </summary>
        private void ToggleGeofences(object sender, RoutedEventArgs e)
        {
            if (!GeofenceMonitor.Current.Geofences.Any())
            {
                foreach (var location in LocationObject.GetLocationObjects())
                {
                    AddFence(location.Id, location.Location);
                }

                DrawGeofences(); // Actual implementation deferred to none shared portion
            }
            else
            {
                GeofenceMonitor.Current.Geofences.Clear();
                RemoveGeofences(); // Actual implementation deferred to none shared portion
            }
        }



        /// <summary>
        /// Creation 
        /// </summary>
        public void AddFence(string key, Geopoint position)
        {
            // Replace if it already exists for this key
            var oldFence = GeofenceMonitor.Current.Geofences.FirstOrDefault(p => p.Id == key);
            if (oldFence != null)
            {
                GeofenceMonitor.Current.Geofences.Remove(oldFence);
            }

            var geocircle = new Geocircle(position.Position, 50);//only circles are supported so I create a circle with 50 meters in diameter.

            const bool singleUse = false;

            MonitoredGeofenceStates mask = 0;

            mask |= MonitoredGeofenceStates.Entered;
            mask |= MonitoredGeofenceStates.Exited;

            // NOTE: Dwelling time!
            var geofence = new Geofence(key, geocircle, mask, singleUse, TimeSpan.FromSeconds(3));//only if you are 3seconds in a geofence (or left it for 10 seconds) something will happen.
            GeofenceMonitor.Current.Geofences.Add(geofence);
        }

        private void ZoomOut(object sender, RoutedEventArgs e)
        {
           
        }

    }
}
