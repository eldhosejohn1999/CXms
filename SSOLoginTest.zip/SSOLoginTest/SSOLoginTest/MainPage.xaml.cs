﻿using Microsoft.Live;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace SSOLoginTest
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        LiveAuthClient authClient;
        bool connected = false;

        public MainPage()
        {
            this.InitializeComponent();
            SSOLogin();
        }

        private async void SSOLogin()
        {
            try
            {
                progressRing.Visibility = Visibility.Visible;
                authClient = new LiveAuthClient();
                signOut.Visibility = connected ? Visibility.Visible : Visibility.Collapsed;


                LiveLoginResult result = await authClient.LoginAsync(new string[] { "wl.basic", "wl.offline_access", "wl.signin", "wl.emails" });

                if (result.Status == LiveConnectSessionStatus.Connected)
                {
                    connected = true;
                    var connectClient = new LiveConnectClient(result.Session);
                    var meResult = await connectClient.GetAsync("me");

                    var photoResult = await connectClient.GetAsync("me/picture");
                    dynamic photoResultdyn = photoResult.Result;
                    var image = new BitmapImage(new Uri(photoResultdyn.location, UriKind.Absolute));
                    this.profileImage.Source = image;
                    profileImage.ImageOpened += ProfileImage_ImageOpened;
                    dynamic meData = meResult.Result;


                    string resultString = "";
                    try
                    {
                        resultString += "Welcome, you have successfully logged in to the app.\n\n";
                        resultString += "First Name: " + (meData.first_name == null ? "Not specified in your account" : meData.first_name);
                        resultString += "\n\nLast Name: " + (meData.last_name == null ? "Not specified in your account" : meData.last_name);
                        resultString += "\n\nFull Name: " + (meData.name == null ? "Not specified in your account" : meData.name);
                        resultString += "\n\nGender: " + (meData.gender == null ? "Not specified in your account" : meData.gender);
                        resultString += "\n\nAccount email id: " + (meData.emails.account == null ? "Not specified in your account" : meData.emails.account);
                        resultString += "\n\nPreffered email id: " + (meData.emails.preferred == null ? "Not specified in your account" : meData.emails.preferred);
                        resultString += "\n\nLink to profile: " + (meData.link == null ? "Not specified in your account" : meData.link);
                    }
                    catch (Exception er)
                    {
                        Debug.WriteLine(er.StackTrace);
                        var messageDialog = new MessageDialog("Error " + er.Message);
                        await messageDialog.ShowAsync();

                    }

                    infoTextBlock.Text = resultString.Length > 0 ? resultString : "Cannot login. Check the connectivity";
                }
            }
            catch (LiveAuthException ex)
            {
                infoTextBlock.Text = ex.Message;
            }
            catch (LiveConnectException ex)
            {

                infoTextBlock.Text = ex.Message;
            }
           
            // Turn off the display of the connection button in the UI.
            signOut.Visibility = connected ? Visibility.Visible : Visibility.Collapsed;

        }

        private void ProfileImage_ImageOpened(object sender, RoutedEventArgs e)
        {

            progressRing.Visibility = Visibility.Collapsed;
        }

        private async void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            this.authClient = new LiveAuthClient("000000004C1A143A");

            try
            {
                if (authClient.CanLogout)
                {
                    authClient.Logout();
                }
                else {
                    var messageDialog = new MessageDialog("Sorry you are currently logged in with the same account in this device. Cant log you out.");
                    await messageDialog.ShowAsync();
                }
            }
            catch (Exception er)
            {
                Debug.WriteLine(er.StackTrace);
                var messageDialog = new MessageDialog("Error " + er.Message);
                await messageDialog.ShowAsync();

            }

        }

    }
}
